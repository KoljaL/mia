/** @type {import('tailwindcss').Config} */



// const production = !process.env.ROLLUP_WATCH;
module.exports = {
    future: {
        purgeLayersByDefault: true,
        removeDeprecatedGapUtilities: true,
    },
    content: ['./src/**/*.{svelte,js,ts}'],
    plugins: [require('daisyui')],
};