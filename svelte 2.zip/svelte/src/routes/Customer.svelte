<script>
    import { onMount } from 'svelte';
    import axios from 'axios';
    // export let params = {};
    let data;
    let customer = [];
    let error = null;

    onMount(async () => {
        try {
            const res = await axios.get('http://localhost:9090/mia/customer');
            console.log(res);
            data = res.data.data;
            customer = res.data.data;
        } catch (e) {
            error = e;
        }
    });
</script>

{#if error !== null}
    <p style="color: red">{error.message}</p>
{:else}
    <pre>
	{JSON.stringify(data, null, 2)}
</pre>
    {#each customer as cus}
        <div class="card w-96 bg-base-100 shadow-xl">
            <figure class="px-10 pt-10">
                <img src="https://placeimg.com/400/225/arch" alt="Shoes" class="rounded-xl" />
            </figure>
            <div class="card-body items-center text-center">
                <h2 class="card-title">Shoes!</h2>
                <p>If a dog chews shoes whose shoes does he choose?</p>
                <div class="card-actions">
                    <button class="btn btn-primary">Buy Now</button>
                </div>
            </div>
        </div>
        <li>
            {cus.name}
        </li>
    {/each}
{/if}
